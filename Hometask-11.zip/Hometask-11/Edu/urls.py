from django.urls import path

from .views import home_page, detail_page, add_Group, edit_Group, delete_Group, login_view, register_view, logout_view, filter_by_category


urlpatterns = [
    path("", home_page, name="home_page"),
    path("detail/<int:pk>/", detail_page, name="detail_page"),
    path("add-Group/", add_Group, name="add_Group"),
    path("edit-Group/<int:pk>/", edit_Group, name="edit_Group"),
    path("delete-Group/<int:pk>/", delete_Group, name="delete_Group"),
    path("login/", login_view, name="login"),
    path("register/", register_view, name="register"),
    path("logout/", logout_view, name="logout"),
    path('category/<str:category_name>/', filter_by_category, name='filter_by_category'),
    
]
