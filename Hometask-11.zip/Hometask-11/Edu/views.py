from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from .models import Group, Category 
from .forms import GroupForm


def home_page(request):
    Group_list = Group.objects.filter(is_going=True).order_by("-started_at")
    categories = Category.objects.all() 
    return render(request, "index.html", {"Group_list": Group_list, "categories": categories})


def detail_page(request, pk):
    Group_item = get_object_or_404(Group, pk=pk, is_going=True)
    Group_item.views_count += 1
    Group_item.save()
    return render(request, "detail.html", {"Group_item": Group_item})


@login_required
def add_Group(request):
    if request.method == "POST":
        form = GroupForm(request.POST, request.FILES)
        if form.is_valid():
            Group = form.save(commit=False)
            Group.user = request.user
            Group.save()
            return redirect("home_page")
    else:
        form = GroupForm()
    return render(request, "add_Group.html", {"form": form})

@login_required
def edit_Group(request, pk):
    Group_item = get_object_or_404(Group, pk=pk)
    if request.user != Group_item.user:
        return redirect("home_page")  
    if request.method == "POST":
        form = GroupForm(request.POST, request.FILES, instance=Group_item)
        if form.is_valid():
            form.save()
            return redirect("detail_page", pk=Group_item.pk)
    else:
        form = GroupForm(instance=Group_item)
    return render(request, "edit_Group.html", {"form": form})


@login_required
def delete_Group(request, pk):
    Group_item = get_object_or_404(Group, pk=pk)
    if request.user == Group_item.user:
        Group_item.delete()
    return redirect("home_page")


def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("home_page")
    else:
        form = AuthenticationForm()
    return render(request, "login.html", {"form": form})


def register_view(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("home_page")
    else:
        form = UserCreationForm()
    return render(request, "register.html", {"form": form})


def logout_view(request):
    logout(request)
    return redirect("home_page")


def filter_by_category(request, category_name):
    Group_list = Group.objects.filter(category__name=category_name, is_going=True).order_by("-started_at")
    return render(request, "index.html", {"Group_list": Group_list})